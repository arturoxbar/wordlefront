import db from "./utils/db";
import userSQL from "../templates/sql/user";
import { User } from "../interfaces/user.interface";
import SMSService from "./utils/sms";
import logger from "./utils/logger";

class UsersService{
    
    constructor(){
    }

    async createUser(user: any){
        let rs = await db.query(userSQL.insert, [user.name, user.email, user.password, user.phone]);
        return this.parseUser({
            ...user,
            id: rs.insertId,
        });
    }

    async updateUser(user: any){
        let rs = await db.query(userSQL.update, [user.name, user.email, user.id]);
        return rs.affectedRows > 0;
    }

    async deleteUser(id: number){
        let rs = await db.query(userSQL.delete, [id]);
        return rs.affectedRows > 0;
    }

    async getUsers(){
        let rs = await db.query(userSQL.get, []);
        return rs.map((user:any)=> this.parseUser(user));
    }

    async getUserById(id: number){
        let rs = await db.query(userSQL.getById, [id]);
        return this.parseUser(rs[0]);
    }

    async getUserByEmail(email: string): Promise<User> {
        const admin = await db.query(userSQL.getByEmail, [email]);
        return this.parseUser(admin[0]);
    }

    async getUserByPhone(phone: string): Promise<User> {
        const admin = await db.query(userSQL.getByPhone, [phone]);
        return this.parseUser(admin[0]);
    }

    async checkEmailExist(email: string): Promise<boolean> {
        const admin = await db.query(userSQL.getByEmail, [email]);
        console.log(email, admin)   
        return admin.length > 0;
    }

    //Validate phone
    async sendCodeValidatePhone(userId: number){
        // Generar un numero random de 4 digitos
        const code = Math.floor(Math.random() * 9000) + 1000;

        let user = await this.getUserById(userId);

        if(!user){
            throw new Error("USER_NOT_FOUND");
        }

        await db.query(userSQL.sendCodeValidatePhone, [code, userId]);

        if(!user.phone){
            throw new Error("PHONE_NOT_FOUND");
        }

        SMSService.sendMessage(user.phone, `Tu código de validación es ${code}`).then(()=>{
            logger.debug(`${user.phone} sendCodeValidatePhone: ${code}`);
        });

        return true;
    }

    async validateAccount(userId: number, code: number){

        try {

            let lastCode = await db.query(userSQL.getLastCode, [userId]);

            if(!lastCode){
                return {error: "CODE_NOT_FOUND"}
            }

            if(lastCode[0].code != code){
                return {error: "CODE_NOT_MATCH"}
            }

            await db.query(userSQL.validateAccount, [userId]);
            
            return {success: true};

        } catch (error) {
            return {error}
        }

    }

    private parseUser(user: any): User{
        return {
            id: user.id,
            name: user.name,
            email: user.email,
            status: user.status,
            password: user.password,
            phone: user.phone,
            validatedAccount: user.validatedAccount
        }
    }

}

export default new UsersService();