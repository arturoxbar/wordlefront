import db from "./utils/db";
import userSQL from "../templates/sql/user";
import roomSQL from "../templates/sql/room";
import logger from "./utils/logger";
import { Room } from "../interfaces/room.interface";

class RoomService {

    constructor(){

    }

    async createRoom(room: any){
        let rs = await db.query(roomSQL.insert, [room.title, room.creator_id, room.word_length, room.number_rounds, room.time_rounds, room.number_oportunities, room.code]);
        return this._parseRoom({id: rs.insertId, ...room});
    }

    async updateRoom(room: any){

    }

    async updateStatus(id: number, status: number){
        let rs = await db.query(roomSQL.updateStatus, [status, id]);
        return rs.affectedRows > 0;
    }

    async deleteRoom(id: number, creator_id?: number){
        let rs = await db.query(roomSQL.delete, [id]);
        return rs.affectedRows > 0;
    }

    async getRooms(){
        let rs = await db.query(roomSQL.get, []);
        return rs.map((room:any)=> this._parseRoom(room));
    }

    async getRoomById(id: number){
        let rs = await db.query(roomSQL.getById, [id]);
        return this._parseRoom(rs[0]);
    }

    async getRoomByCode(code: string){
        let rs = await db.query(roomSQL.getByCode, [code]);
        return this._parseRoom(rs[0]);
    }

    async getRoomByCreator(creatorId: number){
        let rs = await db.query(roomSQL.getByCreator, [creatorId]);
        return rs.map((room:any)=> this._parseRoom(room));
    }

    async getRoomBySearch(search: string){
        let rs = await db.query(roomSQL.getBySearch, ['%'+search+'%']);
        return rs.map((room:any)=> this._parseRoom(room));
    }


    private _parseRoom(room: any): Room{
        return {
            id: room.id,
            title: room.title,
            creator_id: room.creator_id,
            word_length: room.word_length,
            number_rounds: room.number_rounds,
            time_rounds: room.time_rounds,
            number_oportunities: room.number_oportunities,
            code: room.code,
        }
    }

}

export default new RoomService();