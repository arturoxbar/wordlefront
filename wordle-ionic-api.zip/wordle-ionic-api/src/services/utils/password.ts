import bcrypt from 'bcrypt';

class PasswordService {

    saltRound = 12;

    constructor(){
    }

    async comparePassword(password: string, hash: string): Promise<boolean> {
        return bcrypt.compare(password, hash);
    }

    async generatePassword(password: string): Promise<string> {
        return bcrypt.hash(password, this.saltRound);
    }

}

export default new PasswordService();
