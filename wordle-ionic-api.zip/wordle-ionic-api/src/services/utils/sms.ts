import config from '../../config/twilo';
import logger from './logger';

const accountSid = config.TWILIO_ACCOUNT_SID ; // Your Account SID from www.twilio.com/console
const authToken = config.TWILIO_AUTH_TOKEN;   // Your Auth Token from www.twilio.com/console

const client = require('twilio')(accountSid, authToken);

class SMSService {

    constructor(){

    }

    async sendMessage(phone: string, message: string){
        logger.debug(`${phone} send message: ${message}`);
        client.messages.create({
            body: message,
            to: phone,
            from: '+18305213430'
        })
        .then((message:any) => console.log(message.sid))
    }

}

export default new SMSService();