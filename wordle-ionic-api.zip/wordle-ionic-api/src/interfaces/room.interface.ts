export interface Room {
    id: number;
    title: string;
    creator_id: number;
    word_length: number;
    number_rounds: number;
    time_rounds: number;
    number_oportunities: number;
    code?: string;
    words?: Word[];
}

export interface Word {
    word: string;
    rounds: Round[]
}

export interface Round {
    letters: Letter[]
}

export interface Letter{
    letter: string;
    is_found: boolean;
}