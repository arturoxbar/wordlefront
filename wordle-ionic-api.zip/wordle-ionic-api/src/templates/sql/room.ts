const queries = {
    get: `SELECT * FROM rooms WHERE game_status_id = 1;`,
    getById: `SELECT * FROM rooms WHERE id = ?;`,
    getBySearch: `SELECT * FROM rooms WHERE title LIKE ?;`,
    getByCreator: `SELECT * FROM rooms WHERE creator_id = ?;`,
    getByCode: `SELECT * FROM rooms WHERE code = ?;`,
    insert: `INSERT INTO rooms (title, creator_id, word_length, number_rounds, time_rounds, number_oportunities, code) VALUES (?,?,?,?,?,?,?);`,
    update: `UPDATE rooms SET title = ?, word_length = ?, number_rounds = ?, time_rounds = ?, number_oportunities = ? WHERE id = ? AND creator_id = ?;`,
    delete: `UPDATE rooms SET game_status_id = 4 WHERE id = ?;`,
    updateStatus: `UPDATE rooms SET game_status_id = ? WHERE id = ?;`
}

export default queries;