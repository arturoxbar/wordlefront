const query = {
    insert: 
        `INSERT INTO USERS (name, email, password, phone) VALUES (?,?,?,?);`,
    update: 
        `UPDATE USERS SET name = ?, email = ? WHERE id = ?;`,
    delete: 
        `DELETE FROM USERS WHERE id = ?;`,
    get: 
        `SELECT * FROM USERS`,
    getById: 
        `SELECT * FROM USERS WHERE id = ?;`,
    getByEmail: 
        `SELECT * FROM USERS WHERE email = ?;`,
    getByPhone:
        `SELECT * FROM USERS WHERE phone = ?;`,

    sendCodeValidatePhone:
        `INSERT INTO CONFIRMATION_CODE (code, userId) VALUES (?,?);`,

    getLastCode:
        `SELECT * FROM CONFIRMATION_CODE WHERE userId = ? ORDER BY id DESC LIMIT 1;`,

    validateAccount: 
        `UPDATE USERS SET validatedAccount = 1 WHERE id = ?;`,

}


export default query;