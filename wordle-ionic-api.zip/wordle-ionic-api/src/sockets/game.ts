import { ensureAuthSocket } from '../middlewares/auth.middleware';
import Socket from './socket';
import RoomService from '../services/rooms';

class GameSocket {

    _roomId: number;
    _socket: any;

    constructor(roomId:number,  Socket: any) {
        
        console.log('Socket de juego creado:', roomId);

        Socket.on('new-game', (data: any)=>{
            this.startGame();
        })

        this._socket = Socket;
        this._roomId = roomId;

    }

    async startGame(){

        console.log('Iniciando el juego:', this._roomId);

        let options = await RoomService.getRoomById(this._roomId);
        let words = [];

        for(let i = 0; i < options.number_rounds; i++){

            let rounds = [];

            for(let j = 0; j < options.number_oportunities; j++){
                rounds.push({
                    letters: []
                });
            }

            words.push({
                word: this.generateWord(options.word_length + ""),
                rounds
            });

        }

        await RoomService.updateStatus(this._roomId, 2);

        Socket.emitTo('start-game', {roomId: this._roomId, words}, this._roomId);

    }

    generateWord(countLetters: string){
        // @ts-ignore
        return listWords[countLetters][Math.floor(Math.random() * listWords[countLetters].length)];
    }

}

/**
    Lista de palabras para el juego en español entre 4 y 8 letras separadas 
*/
const listWords = {
    '4': ['casa', 'gato', 'cola', 'rama', 'pelo', 'tubo', 'hola'],
    '5': ['perro', 'coche', 'menos', 'estar', 'hacer', 'todos', 'forma'],
    '6': ['cocina', 'cuenta', 'parece', 'sobrar', 'pasado', 'cuando'],
    '7': ['conmigo', 'primera', 'segunda', 'sistema', 'partido', 'revista'],
    '8': ['personas', 'programa', 'presente', 'etiqueta', 'recuerda', 'necesita']
}

export default GameSocket;