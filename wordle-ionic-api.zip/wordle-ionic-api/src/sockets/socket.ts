const { Server } = require('socket.io');
import { ensureAuthSocket } from "../middlewares/auth.middleware";
import RoomService from "../services/rooms";
import GameSocket from './game';

class Socket {

    _io: any;

    constructor() {}

    init(server:any){
        try {
            console.log('Inicializando el Socket');
            let origins = ['*'];

            switch(process.env.NODE_ENV){
                case 'development':
                default:
                    origins.push('http://localhost:4201'), 
                    origins.push('http://localhost:4200'),
                    origins.push('http://localhost:8100')
            }

            this._io = new Server(server, {
                cors: {
                    origin: origins,
                    credentials: true
                }
            });

            this.listen();

        } catch (error) {
            console.log('Error al crear el Socket', error);
        }
    }

    listen() {
        try {

            const rooms:any = {}

            this._io.on('connection', async (socket:any) => {

                let user = await ensureAuthSocket(socket.handshake.headers.token);

                if(user){

                    let room = this.getRoom(0);
                    let gameSocket = new GameSocket(0, this);

                    socket.join(room);

                    //Agrego el usuario a la sala
                    socket.on('join-room', async (data:any) => {

                        room = this.getRoom(data.room_id);
                        socket.join(room);

                        gameSocket = new GameSocket(data.room_id, socket);

                        //Nueva room la agrego a la lista de rooms
                        if(!rooms[room])
                            rooms[room] = [];

                        //Asigno el lider si no existe  
                        let leader = rooms[room].find((user: any) => user.leader);

                        if(!leader)
                            user.leader = true;

                        rooms[room].push(user);

                        console.log('Socket conectado', socket.id, 'a la room: ', data.room_id);
                        this._io.to(room).emit('players-room', rooms[room]);

                    });

                    // Elimino el usuario de la sala
                    socket.on('disconnect', async () => {
                        
                        console.log('Socket desconectado', socket.id);

                        if(rooms[room]){
                            
                            //Filtro el usuario de la sala
                            rooms[room] = rooms[room].filter((item:any) => item.id !== user.id);
                            
                            //Reviso si el usuario era el lider y si no hay nadie en la room lo elimino
                            if(user.leader){
                                if(rooms[room].length > 0)
                                    rooms[room][0].leader = true;
                                else{
                                    console.log('Eliminando la room');
                                    await RoomService.deleteRoom(+room.split(':')[1]);
                                    delete rooms[room];
                                }
                            }

                        }

                        this._io.to(room).emit('players-room', rooms[room]);

                    });


                }else{
                    console.log('No se conecta', socket);
                    socket.disconnect();
                }
            });

        } catch (error) {
            console.log('Error al escuchar el Socket', error);
        }
    }

    emit(event:any, data:any) {
        try {
            this._io.emit(event, data);
        } catch (error) {
            console.log('Error al emitir el Socket', error);
        }
    }

    emitTo(event:any, data:any, roomId:number) {
        try {
            let room = this.getRoom(roomId);
            this._io.to(room).emit(event, data);
        } catch (error) {
            console.log('Error al emitir el Socket', error);
        }
    }

    on(event:any, callback:any) {
        try {
            this._io.on(event, callback);
        } catch (error) {
            console.log('Error al escuchar el Socket', error);
        }
    }


    get io() {
        return this._io;
    }

    getRoom(roomId:number) {
        return `room:${roomId}`;
    }

}

export default new Socket;