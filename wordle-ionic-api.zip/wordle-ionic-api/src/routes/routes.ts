import { Router } from 'express';
import UserRoutes from './users.route';
import RoomRoutes from './rooms.route';

const routes = Router();

// Routes
routes.use('/user', UserRoutes);
routes.use('/room', RoomRoutes);

// Global routes
routes.get('/health', (req,res)=>{
    res.status(200).send('OK');
})

export default routes;