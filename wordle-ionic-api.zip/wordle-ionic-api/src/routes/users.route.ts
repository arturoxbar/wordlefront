import { Router } from "express";
import UserController from "../controllers/user.controller";
import { ensureAuth } from "../middlewares/auth.middleware";

const userRoutes = Router();

//CRUD
userRoutes.all("/crud/*", ensureAuth);
userRoutes.get("/crud/get", UserController.getUser);
userRoutes.get("/crud/getAll", UserController.getUsers);
userRoutes.put("/crud/update", UserController.updateUser);
userRoutes.delete("/crud/id/:id", UserController.deleteUser);

//Sessions
userRoutes.post("/login", UserController.login);
userRoutes.post("/register", UserController.createUser)
userRoutes.post("/validate", ensureAuth, UserController.validateAccount);
userRoutes.put('/update', ensureAuth, UserController.updateUser);
userRoutes.get("/ping", UserController.ping);

export default userRoutes;