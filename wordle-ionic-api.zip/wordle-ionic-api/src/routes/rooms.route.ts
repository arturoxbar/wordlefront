import { Router } from "express";
import { ensureAuth } from "../middlewares/auth.middleware";
import RoomController from "../controllers/room.controller";

const roomRoutes = Router();

//CRUD
//Sessions
roomRoutes.all('*', ensureAuth);

roomRoutes.get('/id/:id', RoomController.getRooms);
roomRoutes.get('/search/:search', RoomController.getRooms);
roomRoutes.get('/creator/:creator', RoomController.getRooms);
roomRoutes.get('/all', RoomController.getRooms);

roomRoutes.post('/create', RoomController.createRoom);
roomRoutes.put('/update', RoomController.updateRoom);
roomRoutes.delete('/delete/id/:id', RoomController.deleteRoom);

export default roomRoutes;