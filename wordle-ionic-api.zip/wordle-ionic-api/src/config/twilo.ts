const config = {
    "TWILIO_ACCOUNT_SID": "AC42ad2217ae17b76230fea1d0b491e30f",
    "TWILIO_AUTH_TOKEN": "3fbd789c3e2936af8dcc610d55bb38ba"
}

export default config;