import { Controller } from "./controller";
import userService from "../services/users";
import { Request, Response } from "express";
import JWTService from "../services/utils/jwt";
import passwordService from "../services/utils/password";
import logger from "../services/utils/logger";
import SMSService from "../services/utils/sms";

class UserController extends Controller{
    
    constructor(){
        super('User');
    }

    // CRUDS
    createUser = async (req: Request, res: Response) => {

        const response = this.getResponse();
        const { name, email, phone, password } = req.body;

        try{
            
            const userExist = await userService.checkEmailExist(email);

            if(userExist){
                response.status = 403;
                response.message = 'EMAIL_FOUND';
                throw new Error('EMAIL_FOUND');
            }

            const hash = await passwordService.generatePassword(password);

            const user = await userService.createUser({
                id: 0, // Un dato que vá a ser reemplazado
                name,
                email,
                password: hash,
                status: 1,
                phone: phone
            });

            await userService.sendCodeValidatePhone(user.id);

            response.data = user;

        } catch(error){
            if(response.status === 200){
                logger.error(`${email} createUser: ${error}`);
                response.status = 500;
                response.message = "SERVER_ERROR";
            }
        }finally{
            res.send(response);
        }
    }

    validateAccount = async (req: Request, res: Response) => {
        const response = this.getResponse();
        const { code } = req.body;
        const { id } = req.user;

        try {
            
            let rs = await userService.validateAccount(id, code);
            
            if(rs.error){
                response.status = 403;
                response.message = rs.error + "";
                throw rs.error;
            }

            response.data = {success: true};

        } catch (error) {
            if(response.status === 200){
                logger.error(`Validate code ${code} for user id ${id}: ${error}`);
                response.status = 500;
                response.message = "SERVER_ERROR";
            }   
        } finally {
            res.send(response);
        }
    }


    getUser = async (req: Request, res: Response) => {
    }

    getUsers = async (req: Request, res: Response) => {
        const response = this.getResponse();

        try {
            const users = await userService.getUsers();

            response.data = users;            

            for(let user of response.data){
                user.password = undefined;
            }
            
        } catch (error) {
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        } finally {
            res.send(response);
        }
    }

    updateUser = async (req: Request, res: Response) => {

        const response = this.getResponse();
        const { 
            name,
            email,
            status
        } = req.body;

        const { id, phone } = req.user;

        try{

            await userService.updateUser({
                id,
                name,
                email,
                status
            });

            response.data = {
                id,
                name,
                email,
                phone
            };

        } catch(error){
            console.log(error);
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        } finally {
            res.send(response);
        }

    }

    deleteUser = async (req: Request, res: Response) => {

        const response = this.getResponse();

        try{
            const { id } = req.params;
            await userService.deleteUser(+id);
        } catch(error) {
            console.log(error);
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        } finally {
            res.send(response);
        }

    }

    // Sessions
    login = async (req: Request, res: Response) => {

        const response = this.getResponse();
        const { email, password } = req.body;
    
        try{
            
            const existUser = await userService.checkEmailExist(email);

            if(!existUser){
                response.status = 404;
                response.message = 'EMAIL_NOT_FOUND';
                throw new Error('EMAIL_NOT_FOUND');
            }

            const user = await userService.getUserByEmail(email);
            const isPasswordValid = await passwordService.comparePassword(password, user.password as string);

            if(!isPasswordValid){
                response.status = 403;
                response.message = 'PASSWORD_NOT_MATCH';
                throw new Error('PASSWORD_NOT_MATCH');
            }

            if(!user.status){
                response.status = 403;
                response.message = 'ACCOUNT_DISABLED';
                throw new Error('ACCOUNT_DISABLED');
            }

            delete user.password;

            const token = JWTService.generateToken({
                ...user
            });

            response.data = {
                token,
                profile: {
                    ...user
                }
            };

        } catch (err) {
            
            logger.error(`${email} login: ${err}`);
            
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }

        }finally{

            res.status(200).send(response);

        }

    }

    ping = async (req: Request, res: Response) => {
        const response = this.getResponse();
        try{
            response.data = 'PONG';
        } catch (err) {
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        }finally{
            res.status(200).send(response);
        }    
    }

    logout = async (req: Request, res: Response) => {
    }

}

export default new UserController();