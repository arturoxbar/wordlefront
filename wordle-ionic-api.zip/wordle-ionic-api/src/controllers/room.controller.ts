import { Controller } from "./controller";
import { Request, Response} from "express";
import roomService from "../services/rooms";
import uniqueId from "uniqid";

class RoomController extends Controller{

    constructor(){
        super('Room');
    }

    // CRUDS
    getRooms = async (req: Request, res: Response) => {

        const response = this.getResponse();

        try{

            const {id, search, creator} = req.params;

            if(id){
                const room = await roomService.getRoomById(+id);
                response.data = room;
            }else if(search){
                const rooms = await roomService.getRoomBySearch(search);
                response.data = rooms;
            }else if(creator){
                const rooms = await roomService.getRoomByCreator(+creator);
                response.data = rooms;
            }else{
                const rooms = await roomService.getRooms();
                response.data = rooms;
            }

        }catch(error){
            console.log(error);
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        }finally{
            res.send(response);
        }

    }
    
    createRoom = async (req: Request, res: Response) => {

        const response = this.getResponse();

        try {

            const code = uniqueId().slice(0, -4);
            const body = {
                ...req.body,
                code,
                title: "Room #"+code,
                creator_id: req.user.id,
            }

            const room = await roomService.createRoom(body);

            response.data = room;

        } catch (error) {
            console.log(error);
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        } finally {
            res.send(response);
        }

    }

    updateRoom = async (req: Request, res: Response) => {
        const response = this.getResponse();
        try{
        }catch(error){
        }finally{
        }
    }

    deleteRoom = async (req: Request, res: Response) => {
        const response = this.getResponse();
        try{
            const { id } = req.params;
            await roomService.deleteRoom(+id, req.user.id);
        }catch(error){
            console.log(error);
            if(response.status == 200){
                response.status = 500;
                response.message = 'SERVER_ERROR';
            }
        }finally{
            res.send(response);
        }
    }

}

export default new RoomController();